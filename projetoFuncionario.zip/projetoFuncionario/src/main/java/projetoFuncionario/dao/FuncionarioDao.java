package projetoFuncionario.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.RollbackException;

import projetoFuncionario.model.Funcionarios;
import projetoFuncionario.utils.Conexao;

public class FuncionarioDao<T> {

	private static EntityManager em = Conexao.conexaoGeneratoin();
//	private static EntityManagerFactory emf;

	public String cadastra(T t) {

		try {
			em.getTransaction().begin();
			em.persist(t);
			em.getTransaction().commit();
		} catch (RollbackException erro) {
			return erro.getMessage();
		} catch (Exception erro) {
			return erro.getMessage();
		}
		return null;
	}
	
	
	@SuppressWarnings("unchecked")
	public static List<Funcionarios> buscaFuncionario(){
		List<Funcionarios> funcio = null;
		try {
			funcio = em.createQuery("from Funcionarios f").getResultList();
		} catch (Exception e) {
		return funcio;
		}
		return funcio;
	}
	
	public Funcionarios buscarPorMatricula(String matricula) {
	     Funcionarios funcio = null;
		try {
			funcio = em.find(Funcionarios.class, matricula);
		} catch (Exception e) {
			System.out.println("erro "+e.getMessage());
		}
		return funcio;
	}
	
	public static Funcionarios removerFuncnionario(String matricula) {
		Funcionarios func = null;
		try {
			func = em.find(Funcionarios.class, matricula);
			em.getTransaction().begin();
			em.remove(func);
			em.getTransaction().commit();
		} catch (Exception e) {
			System.out.println("erro "+e.getMessage());
			em.getTransaction().rollback();
		}
		return func;
		
	}
}











