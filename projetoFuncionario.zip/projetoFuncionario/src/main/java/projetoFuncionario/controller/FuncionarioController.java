package projetoFuncionario.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import projetoFuncionario.dao.FuncionarioDao;
import projetoFuncionario.model.Funcionarios;

 
@WebServlet("/funcionario")
public class FuncionarioController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public FuncionarioController() {
        super();
     }
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
 		List<?> funcio = FuncionarioDao.buscaFuncionario();
 		request.setAttribute("funcionarios", funcio);
 		RequestDispatcher re = request.getRequestDispatcher("lista-funcionarios.jsp");
 		re.forward(request, response);	        
	}

 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Funcionarios funcionario = new Funcionarios();
		funcionario.setMatricula(request.getParameter("matricula"));
		funcionario.setTelefone(request.getParameter("telefone"));
		funcionario.setNome(request.getParameter("nome"));
		funcionario.setCargo(request.getParameter("cargo"));
		funcionario.setEmail(request.getParameter("email"));
		FuncionarioDao<Funcionarios> insert = new FuncionarioDao<Funcionarios>();
		insert.cadastra(funcionario);
		doGet(request, response);
	}
	


}
