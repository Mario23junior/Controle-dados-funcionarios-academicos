package projetoFuncionario.utils;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Conexao {
	
	private static EntityManager controleEntity = null;
	private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("projetoFuncionario");
	
  static {
	  conexaoGeneratoin();
  }
  
  public static EntityManager conexaoGeneratoin() {
	  if(controleEntity == null) {
		  controleEntity = emf.createEntityManager();
	  }
	return controleEntity;
  }
}
